function [funclist, gradlist, solution] = SGD_Polyak(func, grad, x0, itermax, f_star)
% Subgradient method with Polyak's step size rule
%
% Input
% - func: the objective function
% - grad: the subgradient of objective function
% - x0: the initial point
% - itermax: the maximum iteration number
% - f_star: the optimal value of the problem
% Output
% - funclist: the function value of each iteration
% - gradlist: the Euclidean norm of the gradient of each iteration
% - solution: the optimal solution solved by the algorithm

funclist = zeros(1,itermax);
gradlist = zeros(1,itermax);

% the first iteration
x = x0;
funclist(1) = func(x);
gradlist(1) = norm(grad(x));
% m = funclist(1);        % minimum function value

for iter = 2:itermax
    
    p = -grad(x);
    
    % Polyak's step size rule
    t = (func(x)-f_star)/norm(p)^2;  
    
    % update
    x = x + t*p;
    
%     m = min(m, func(x));
%     funclist(iter) = m;
    funclist(iter) = func(x);
    gradlist(iter) = norm(grad(x));
    
end

solution = x;

end

