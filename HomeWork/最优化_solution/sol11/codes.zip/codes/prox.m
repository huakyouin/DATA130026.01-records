function y = prox(t,tau,x)
% proximal mapping of tau*norm(x,1)
y  = zeros(length(x),1);
ind = find(x>t*tau);
y(ind) = x(ind)- t*tau;
ind = find(x<-t*tau);
y(ind) = x(ind)+ t*tau;

